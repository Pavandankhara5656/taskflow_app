import 'package:flutter_bloc/flutter_bloc.dart';
import '../db/task_database.dart';
import '../models/task.dart';
import 'task_event.dart';
import 'task_state.dart';

class TaskBloc extends Bloc<TaskEvent, TaskState> {
  final TaskDatabase database;
  List<Task> _allTasks = [];

  TaskBloc(this.database) : super(TaskInitial()) {
    on<LoadTasks>((event, emit) async {
      emit(TaskLoading());
      final tasks = await database.readAllTasks();
      _allTasks = tasks;
      emit(TaskLoaded(tasks));
    });

    on<AddTask>((event, emit) async {
      await database.create(event.task);
      add(LoadTasks());
    });

    on<UpdateTask>((event, emit) async {
      await database.update(event.task);
      add(LoadTasks());
    });

    on<DeleteTask>((event, emit) async {
      await database.delete(event.id);
      add(LoadTasks());
    });

    on<FilterTasks>((event, emit) {
      List<Task> filtered;
      if (event.filter == 'Completed') {
        filtered = _allTasks.where((t) => t.isCompleted).toList();
      } else if (event.filter == 'Pending') {
        filtered = _allTasks.where((t) => !t.isCompleted).toList();
      } else {
        filtered = _allTasks;
      }
      emit(TaskLoaded(filtered));
    });

    on<SortTasks>((event, emit) {
      final sorted = List<Task>.from(_allTasks);
      sorted.sort((a, b) => a.dueDate.compareTo(b.dueDate));
      emit(TaskLoaded(sorted));
    });
  }
}