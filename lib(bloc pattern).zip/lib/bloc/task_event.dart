import '../models/task.dart';

abstract class TaskEvent {}

class LoadTasks extends TaskEvent {}

class AddTask extends TaskEvent {
  final Task task;
  AddTask(this.task);
}

class UpdateTask extends TaskEvent {
  final Task task;
  UpdateTask(this.task);
}

class DeleteTask extends TaskEvent {
  final int id;
  DeleteTask(this.id);
}

class FilterTasks extends TaskEvent {
  final String filter;
  FilterTasks(this.filter);
}

class SortTasks extends TaskEvent {}
