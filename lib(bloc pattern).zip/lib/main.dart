import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taskflow_app/screens/task_list_screen.dart';
import 'bloc/task_bloc.dart';
import 'bloc/task_event.dart';
import 'db/task_database.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final taskDatabase = TaskDatabase.instance;
  await taskDatabase.database; // Ensure DB is ready
  runApp(MyApp(taskDatabase: taskDatabase));
}

class MyApp extends StatelessWidget {
  final TaskDatabase taskDatabase;

  const MyApp({super.key, required this.taskDatabase});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => TaskBloc(taskDatabase)..add(LoadTasks()),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Task Manager App',
        theme: ThemeData(
          primarySwatch: Colors.deepPurple,
          useMaterial3: true,
        ),
        home: TaskListScreen(),
      ),
    );
  }
}
